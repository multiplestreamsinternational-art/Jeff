import copy, unittest
import knowledgecoin as k


class Base(unittest.TestCase):
    def setUp(self):
        k.set_network("testnet")
        self._params = dict(k.PARAMS)
        self.t = [k.GENESIS_TIME]
        k.CLOCK["now"] = lambda: self.t[0]

    def tearDown(self):
        k.PARAMS.clear(); k.PARAMS.update(self._params)

    def mine(self, ch, who="a" * 40, dt=k.TARGET_BLOCK_TIME):
        self.t[0] += dt
        return ch.mine(who)


class TestSupply(Base):
    def test_cap_and_halving(self):
        self.assertLessEqual(k._check_supply_cap(), k.MAX_SUPPLY)
        self.assertEqual(k.subsidy(k.HALVING_INTERVAL), k.subsidy(0) // 2)
        self.assertEqual(k.subsidy(k.HALVING_INTERVAL * 64), 0)


class TestTx(Base):
    def setUp(self):
        super().setUp()
        self.priv = k.new_key()
        self.addr = k.addr_of(k.pub_hex(self.priv))
        self.st = k.State(); self.st.credit(self.addr, 10**12)

    def test_tampered_tx_rejected(self):
        tx = k.make_tx(self.priv, "TRANSFER", {"to": "b" * 40, "amount": 5}, 0)
        tx["data"]["amount"] = 10**9
        self.assertFalse(k.tx_static_ok(tx))

    def test_replay_rejected(self):
        tx = k.make_tx(self.priv, "TRANSFER", {"to": "b" * 40, "amount": 5}, 0)
        self.st.apply_tx(tx, 1)
        with self.assertRaises(ValueError): self.st.apply_tx(tx, 1)

    def test_overspend_rejected(self):
        tx = k.make_tx(self.priv, "TRANSFER", {"to": "b" * 40, "amount": 10**13}, 0)
        with self.assertRaises(ValueError): self.st.apply_tx(tx, 1)
        self.assertEqual(self.st.bal[self.addr], 10**12)      # state untouched


class TestDifficulty(Base):
    def _fake(self, spacing):
        ch = k.Chain(); target = k.MAX_TARGET // 4
        for i in range(1, 70):
            ch.blocks.append({"header": {"height": i, "time": k.GENESIS_TIME + i * spacing,
                                         "target": format(target, "x")}, "txs": []})
        return ch, target

    def test_slow_blocks_get_easier(self):
        ch, t = self._fake(1200); self.assertGreater(ch.expected_target(70), t)

    def test_fast_blocks_get_harder(self):
        ch, t = self._fake(150); self.assertLess(ch.expected_target(70), t)

    def test_never_easier_than_genesis(self):
        ch, _ = self._fake(10**5); self.assertLessEqual(ch.expected_target(70), k.MAX_TARGET)


class TestGovernance(Base):
    def setUp(self):
        super().setUp()
        k.PARAMS.update(voting_blocks=2, quorum_pct=1, timelock_blocks=2)
        self.st = k.State(); self.st.treasury = 10**9; self.st.issued = 10**9
        self.a, self.b = k.new_key(), k.new_key()
        self.A, self.B = k.addr_of(k.pub_hex(self.a)), k.addr_of(k.pub_hex(self.b))
        self.st.credit(self.A, 10**9); self.st.credit(self.B, 5 * 10**9)

    def blk(self, h): self.st.apply_block({"header": {"height": h, "miner": "c" * 40}, "txs": []})

    def propose(self, amount):
        tx = k.make_tx(self.a, "PROPOSE", {"title": "t", "uri": "https://x.org", "amount": amount,
                                             "recipient": "d" * 40}, 0)
        self.st.apply_tx(tx, 1); return k.tx_id(tx)

    def test_grant_cap(self):
        with self.assertRaises(ValueError): self.propose(self.st.treasury * k.MAX_GRANT_PCT // 100 + 1)

    def test_veto_in_challenge_window(self):
        pid = self.propose(1000)
        self.st.apply_tx(k.make_tx(self.a, "VOTE", {"proposal": pid, "yes": True}, 1), 2)
        self.blk(3)                                           # vote ends -> passed
        self.assertEqual(self.st.props[pid]["status"], "passed")
        with self.assertRaises(ValueError):                   # late YES votes are not allowed
            self.st.apply_tx(k.make_tx(self.b, "VOTE", {"proposal": pid, "yes": True}, 0), 4)
        self.st.apply_tx(k.make_tx(self.b, "VOTE", {"proposal": pid, "yes": False}, 0), 4)
        self.blk(5)
        self.assertEqual(self.st.props[pid]["status"], "vetoed")
        self.assertNotIn("d" * 40, self.st.bal)


class TestChain(Base):
    def test_longest_work_chain_wins(self):
        a, b = k.Chain(), k.Chain()
        for _ in range(2): self.mine(a, "a" * 40)
        for _ in range(3): self.mine(b, "b" * 40)
        self.assertTrue(a.try_replace(copy.deepcopy(b.blocks)))
        self.assertEqual(a.height(), 3)
        self.assertFalse(a.try_replace(copy.deepcopy(b.blocks)))   # not strictly more work

    def test_tampered_chain_rejected(self):
        a, b = k.Chain(), k.Chain()
        for _ in range(3): self.mine(b)
        bad = copy.deepcopy(b.blocks); bad[2]["header"]["miner"] = "e" * 40
        self.assertFalse(a.try_replace(bad))


if __name__ == "__main__":
    unittest.main()
