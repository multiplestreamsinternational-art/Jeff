# KnowledgeCoin testnet launch checklist

Goal: find consensus bugs while coins are worthless. Mainnet only after the go/no-go list at the bottom is fully ticked.

## Phase 0 - Prepare the repo (week 1)
- [ ] Choose a final name and ticker (KNC is, as far as I know, already used by Kyber Network). Check trademarks.
- [ ] Create a public GitHub repo with `knowledgecoin.py`, `test_knowledgecoin.py`, and an MIT or Apache-2.0 `LICENSE`.
- [ ] Add CI at `.github/workflows/ci.yml`:
  ```yaml
  name: ci
  on: [push, pull_request]
  jobs:
    test:
      runs-on: ubuntu-latest
      steps:
        - uses: actions/checkout@v4
        - uses: actions/setup-python@v5
          with: { python-version: "3.12" }
        - run: python -m unittest -v
        - run: python knowledgecoin.py demo
  ```
- [ ] Write a one-page `SPEC.md`: supply schedule, block format, tx types, treasury rules, grant cap (5%), challenge window, LWMA window.
- [ ] Add `SECURITY.md` with a private contact for vulnerability reports.
- [ ] Publish the testnet genesis hash in the README so everyone can verify they are on the same chain.

## Phase 1 - Free infrastructure (week 1-2)
- [ ] 2-3 seed nodes on always-free cloud tiers or volunteer machines (`python knowledgecoin.py node --port 8333 --miner <addr> --peers ...`).
- [ ] Site on GitHub Pages: what it is, how to run a node, how to mine, how to propose a grant.
- [ ] Community channel (Discord/Matrix/forum) with a code of conduct.
- [ ] Simple block explorer (read `/chain`, `/info`, `/proposals`).

## Phase 2 - Break it on purpose (weeks 2-8)
- [ ] Invite reviewers to attack: double spends, malformed blocks, timestamp games, huge txs, mempool spam, reorgs.
- [ ] Simulate hashrate swings (turn big miners on/off) and watch block times stay near 10 minutes.
- [ ] Run at least 3 grant proposals end to end, including one that gets vetoed in the challenge window.
- [ ] Record every bug and fix in a public changelog. Do not hide failures.
- [ ] Reward good reports with public credit (testnet coins have no value).

## Phase 3 - Hardening before mainnet
- [ ] Replace pure-Python ECDSA with libsecp256k1 (e.g. `coincurve`) or port the node to Rust/Go.
- [ ] Peer discovery, peer banning, request size limits, rate limits.
- [ ] Persistent state database (not full chain replay) and a faster block validation path.
- [ ] Early-chain safety: decide on checkpoints for the first months and say so publicly.
- [ ] Independent code review by someone outside the author group.
- [ ] Lawyer review in your country, and a plain-language risk statement on the website (no price promises, ever).

## Mainnet go / no-go
Launch only if ALL are true:
- [ ] Testnet ran 8+ weeks with no unfixed consensus bug in the last 4 weeks.
- [ ] External review done and findings fixed.
- [ ] At least 20 independent node operators on testnet.
- [ ] Genesis time announced 4+ weeks ahead, then set in `NETWORKS["mainnet"]["time"]`.
- [ ] No premine, no private sale. Everyone mines from block 1.
- [ ] Mainnet initial difficulty (`bits`) chosen from testnet hashrate data.
- [ ] Reproducible build instructions and signed release tag.

## Honest expectations
- Early miners will hold most coins; announce launch widely and early to reduce this.
- The treasury is only worth what KNC is worth. Early grants may be symbolic.
- A small proof-of-work chain can be attacked by renting hashrate. Be transparent about this.
